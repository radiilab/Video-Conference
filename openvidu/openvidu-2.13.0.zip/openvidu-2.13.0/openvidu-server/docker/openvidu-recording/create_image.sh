docker build --rm -t openvidu/openvidu-recording .
