pref("general.config.filename", "customconfig.cfg");
pref("general.config.obscure_value", 0);