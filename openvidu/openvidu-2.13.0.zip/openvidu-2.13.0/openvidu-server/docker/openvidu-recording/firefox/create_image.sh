docker build --rm -t openvidu/openvidu-recording:2.10.0-firefox .
