docker build --rm -t openvidu/openvidu-coturn .
