package io.openvidu.server.coturn;

public class DockerCoturnCredentialsService extends CoturnCredentialsService {

	@Override
	public TurnCredentials createUser() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteUser(String user) {
		// TODO Auto-generated method stub
		return false;
	}

}
