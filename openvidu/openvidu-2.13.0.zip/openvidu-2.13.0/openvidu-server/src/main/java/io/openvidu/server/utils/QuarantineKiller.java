package io.openvidu.server.utils;

public interface QuarantineKiller {

	public void dropMediaNode(String mediaNodeId);

}
