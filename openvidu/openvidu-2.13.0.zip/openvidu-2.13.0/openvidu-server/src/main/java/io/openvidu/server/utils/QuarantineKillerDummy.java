package io.openvidu.server.utils;

public class QuarantineKillerDummy implements QuarantineKiller {

	@Override
	public void dropMediaNode(String mediaNodeId) {
	}

}
