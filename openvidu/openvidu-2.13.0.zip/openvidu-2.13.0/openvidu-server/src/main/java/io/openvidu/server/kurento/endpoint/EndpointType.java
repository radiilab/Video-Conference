package io.openvidu.server.kurento.endpoint;

public enum EndpointType {

	WEBRTC_ENDPOINT, PLAYER_ENDPOINT, RTP_ENDPOINT

}
