import { OpenVidu } from './OpenVidu/OpenVidu';

if (window) {
    window['OpenVidu'] = OpenVidu;
}